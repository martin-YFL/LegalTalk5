package com.martin.mvc.legaltalk;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class RegistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);
    }
}
